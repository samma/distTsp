package tasks;

public class TspImpl {

}
